1. List students with row numbers by student_id order

2. Top 5 youngest students by DOB using CTE

3. Rank majors by number of students

4. Top 3 languages overall

5. Within each country, rank majors by size

6. Rank countries by average birth year

7. Row number within each gender

8. Rank languages inside USA

9. CTE to compute per-major share of females

10. Rank countries by number of distinct languages

