1. Count per country.

2. Count per language.

3. Count per major.

4. Count by gender.

5. Top 3 countries by count.

6. Oldest student.

7. Youngest student.

8. Average birth year by country.

9. Count per (country, language).

10. Majors with at least 12 students.

11. Languages with fewer than 10 students.

12. Countries with >=20% CS majors.

13. Most common language per country (ties kept).

14. Share of each major overall.

15. Country-language combos with at least 5 students.

16. Middle 10 student_ids (by order).

17. Email username length > 12 count.

18. Earliest and latest DOB year per major.

19. Total students and USA students.

20. Count per birth decade.

