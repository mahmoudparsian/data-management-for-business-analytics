1. Rank languages by count.

2. Top 2 languages per country.

3. Countries ranked by avg birth year.

4. Top 3 last names per major.

5. CS share by country with totals.

6. Running count by student_id.

7. Most common first_name (ties).

8. Countries where ENGLISH is not the top language.

9. Approx median birth year per language.

10. Most international major (most distinct countries).

11. Rank countries by count within each major.

12. Top 5 most frequent name pairs.

13. Country with youngest average population.

14. Percent of females per country.

15. Language proportions within USA.

16. Top major per birth decade.

17. Countries where >=60% speak ENGLISH.

18. Majors where USA is not the top country.

19. Languages where FEMALE ranks #1 by count.

