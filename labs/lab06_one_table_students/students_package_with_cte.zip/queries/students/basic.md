1. List all students.

2. Show first_name, last_name, and email.

3. Find students from INDIA.

4. Find students who speak FRENCH.

5. List Computer Science majors.

6. Show students born after 1995-01-01.

7. Find students named Emma.

8. 10 most recent students by id.

9. Students from USA or CANADA.

10. Students with last name Patel.

11. Emails ending with example.edu.

12. Distinct countries.

13. Distinct languages.

14. Students born in 1990.

15. Not Finance majors.

16. First 5 alphabetically by last, first.

17. Count students named Liam.

18. Last names starting with 'Ro'.

19. From GERMANY who speak GERMAN.

20. Biology majors born before 1990-01-01.

