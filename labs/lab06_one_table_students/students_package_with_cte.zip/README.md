# MySQL Students Package
See data/, queries/, and starter_notebook.ipynb. Load with SQL inserts or CSV.
