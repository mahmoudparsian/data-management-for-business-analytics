1. List all customers.

2. Show all products in the Electronics category.

3. Find all sales paid by CASH.

4. List all distinct countries of customers.

5. Find names and ages of all customers from USA.

6. List customers older than 60.

7. Show products in Home or Garden categories.

8. Show sales that happened in 2024.

9. Find customers whose name starts with 'Customer1'.

10. List all FEMALE customers.

11. Get product with product_id = 5.

12. Find sales where price > 300.

13. Show the 10 most expensive transactions.

14. List customers from CANADA ordered by age descending.

15. Find products whose name contains '5'.

16. Return the first 5 customers by customer_id.

17. Show sales made using CREDIT on or after 2023-01-01.

18. List all sales for customer_id = 7.

19. Show all products not in the MISC category.

20. Find customers aged between 25 and 35 inclusive.

