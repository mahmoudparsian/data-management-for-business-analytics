1. Count number of customers per country.

2. Find average price of sales per sale_type.

3. Compute total sales revenue.

4. Count number of products per category.

5. Find average age of customers by gender.

6. Total revenue per customer (with names).

7. Total revenue per product (with names).

8. Number of distinct customers who purchased anything.

9. Number of distinct products sold.

10. Total sales count per year.

11. Average sale price per year.

12. Minimum and maximum sale price overall.

13. Average spend per customer country.

14. Total revenue by sale_type and year.

15. Count sales per product category.

16. Average price per product category.

17. Top 10 customers by number of purchases.

18. Top 10 products by revenue.

19. Sales count per month in 2024.

20. Average age of purchasing customers per sale_type.

