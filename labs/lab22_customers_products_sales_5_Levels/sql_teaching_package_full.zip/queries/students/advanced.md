1. Customers who bought from all categories ever sold (set division).

2. Products never purchased by customers in Germany.

3. Monthly revenue and month-over-month growth (using LAG).

4. Top customer in each country by spending.

5. Customers who bought more than 10 distinct products.

6. Pareto analysis: cumulative revenue share by customers.

7. Products with revenue in the top 10% (NTILE).

8. Yearly revenue, best month per year.

9. Customers with at least one purchase in consecutive years.

10. Category mix per country (share of revenue).

11. Customers who never used CASH.

12. Longest gap in days between purchases per customer.

13. Top 3 categories by number of distinct buyers.

14. Customers whose average purchase price increased year-over-year.

15. Products with zero sales in any given year where other products sold.

16. Recursive CTE: list months from min to max sale_date.

17. Customers whose second purchase is greater or equal to their first.

18. Customers and the share of revenue they contribute within their country.

19. Most expensive product per category by average selling price.

20. Find the country with the highest revenue variance across months.

