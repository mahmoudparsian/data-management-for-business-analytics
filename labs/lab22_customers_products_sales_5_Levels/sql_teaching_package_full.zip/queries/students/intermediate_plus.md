1. Customers who spent above the average sale price overall.

2. Products sold more times than the average product.

3. Customers ranked by spending within country (CTE).

4. Categories with total sales above 5000.

5. Customers who never bought Jewelry.

6. Customers who bought at least one product in every category that was sold.

7. Products whose average price is higher than their category average.

8. Customers with spending above their country average.

9. Top 3 customers per country by distinct products.

10. Customers who bought from exactly 3 distinct categories.

11. Years where revenue exceeded the prior year.

12. Customers whose maximum single purchase exceeds 450.

13. Categories ranked by number of buyers.

14. Products that were never bought with CASH.

15. Countries where average transaction price is above global average.

16. Top 5 months by revenue across all years.

17. Customers whose total CASH spending exceeds CREDIT spending.

18. Products that are top-1 by revenue within their category.

19. Customers who purchased in every year products were sold.

