1. Top 5 customers by total spending.

2. Rank products by total sales count.

3. Find youngest customer in each country.

4. Average sales price per customer.

5. Total revenue per year.

6. Rank customers by spending (global).

7. Rank customers by spending within country.

8. Find oldest customer in each country.

9. Running total of revenue by year.

10. Top 3 products by revenue per category.

11. Customers with more than 5 purchases.

12. Products with average sale price above 300.

13. Customers buying at least 10 distinct products.

14. Monthly revenue with rank per year.

15. Rank countries by total revenue.

16. Top 5 youngest purchasers (with ties).

17. Customers with the highest single transaction (top 10).

18. Customers ranked by count of CREDIT purchases.

19. Products ranked by number of distinct buyers.

