# SQL Teaching Package

This package provides a full MySQL teaching dataset with schema, CSV/SQL inserts, and 100 SQL practice queries.

## Contents
- `data/schema.sql` : Schema definition (no ENUMs, includes PKs and FKs)
- `data/customers.csv` / `customers.sql` : 63 customers (3 never purchase)
- `data/products.csv` / `products.sql` : 33 products (3 never sold)
- `data/sales_100.csv` / `sales_100.sql` : 100 sales records
- `data/sales_400.csv` / `sales_400.sql` : 400 sales records
- `queries/students/` : 5 markdown files with English-only queries (20 each)
- `queries/instructor/` : 5 markdown files with English+SQL solutions (20 each)

## Step-by-Step Instructions

### 1. Create the Database
```bash
mysql -u root -p -e "CREATE DATABASE teaching_db;"
```

### 2. Load Schema
```bash
mysql -u root -p teaching_db < data/schema.sql
```

### 3. Load Data (Option 1: SQL inserts)
```bash
mysql -u root -p teaching_db < data/customers.sql
mysql -u root -p teaching_db < data/products.sql
mysql -u root -p teaching_db < data/sales_100.sql   # or sales_400.sql
```

### 4. Load Data (Option 2: CSV import)
Start MySQL shell and run:
```sql
LOAD DATA LOCAL INFILE 'data/customers.csv'
INTO TABLE customers
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA LOCAL INFILE 'data/products.csv'
INTO TABLE products
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA LOCAL INFILE 'data/sales_100.csv'
INTO TABLE sales
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;
```

### 5. Practice Queries
- Students: open files under `queries/students/`
- Instructors: open files under `queries/instructor/`

---

## Starter Python Script to Import CSVs into MySQL

```python
import pandas as pd
import mysql.connector

# Connect to MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="yourpassword",
    database="teaching_db",
    allow_local_infile=True
)
cursor = conn.cursor()

# Load CSVs
tables = ["customers", "products", "sales"]
files = ["data/customers.csv", "data/products.csv", "data/sales_100.csv"]

for table, file in zip(tables, files):
    query = f"""LOAD DATA LOCAL INFILE '{file}'
    INTO TABLE {table}
    FIELDS TERMINATED BY ','
    LINES TERMINATED BY '\n'
    IGNORE 1 ROWS;"""
    cursor.execute(query)
    conn.commit()

cursor.close()
conn.close()
print("Data loaded successfully!")
```

Replace `yourpassword` with your MySQL root password.

---

Enjoy teaching and learning SQL!
