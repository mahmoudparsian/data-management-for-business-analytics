# Lab-4 – Intermediate Plus (30 queries)

> Table: `employees(emp_id, first_name, last_name, age, degree, gender, country, department, hire_date, salary)`

### 1. Salary > dept avg by 20%.
```sql
WITH d AS (SELECT department, AVG(salary) AS avg_sal FROM employees GROUP BY department)
SELECT e.emp_id, e.first_name, e.department, e.salary, d.avg_sal FROM employees e JOIN d ON e.department=d.department WHERE e.salary > 1.2*d.avg_sal ORDER BY e.salary DESC;
```

### 2. Salary < country avg by 15%.
```sql
WITH c AS (SELECT country, AVG(salary) AS avg_sal FROM employees GROUP BY country)
SELECT e.emp_id, e.first_name, e.country, e.salary, c.avg_sal FROM employees e JOIN c ON e.country=c.country WHERE e.salary < 0.85*c.avg_sal ORDER BY e.salary ASC;
```

### 3. Top 3 salaries per department (ROW_NUMBER).
```sql
WITH r AS (SELECT emp_id, first_name, department, salary, ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) AS rn FROM employees)
SELECT * FROM r WHERE rn<=3 ORDER BY department, salary DESC;
```

### 4. DENSE_RANK departments by avg salary.
```sql
WITH a AS (SELECT department, AVG(salary) AS a FROM employees GROUP BY department)
SELECT department, ROUND(a) AS avg_sal, DENSE_RANK() OVER (ORDER BY a DESC) AS rnk FROM a ORDER BY rnk;
```

### 5. RANK countries by headcount.
```sql
WITH c AS (SELECT country, COUNT(*) AS n FROM employees GROUP BY country)
SELECT country, n, RANK() OVER (ORDER BY n DESC) AS rnk FROM c ORDER BY rnk;
```

### 6. ROW_NUMBER by salary desc (top 20).
```sql
SELECT emp_id, first_name, salary, ROW_NUMBER() OVER (ORDER BY salary DESC) AS rn FROM employees ORDER BY salary DESC LIMIT 20;
```

### 7. Approx 90th percentile via NTILE.
```sql
WITH r AS (SELECT salary, NTILE(10) OVER (ORDER BY salary) AS decile FROM employees)
SELECT MIN(salary) AS approx_p90 FROM r WHERE decile=10;
```

### 8. Running total salaries by hire year.
```sql
WITH s AS (SELECT YEAR(hire_date) AS yr, SUM(salary) AS total FROM employees GROUP BY YEAR(hire_date))
SELECT yr, total, SUM(total) OVER (ORDER BY yr) AS running FROM s ORDER BY yr;
```

### 9. Dept salary share of total.
```sql
WITH t AS (SELECT SUM(salary) AS total FROM employees), d AS (SELECT department, SUM(salary) AS dep_total FROM employees GROUP BY department)
SELECT d.department, d.dep_total, ROUND(d.dep_total*100.0/t.total,2) AS pct FROM d, t ORDER BY pct DESC;
```

### 10. Headcount share by country per department.
```sql
WITH c AS (SELECT department, country, COUNT(*) AS n FROM employees GROUP BY department, country), t AS (SELECT department, SUM(n) AS dep_total FROM c GROUP BY department)
SELECT c.department, c.country, ROUND(c.n*100.0/t.dep_total,2) AS pct FROM c JOIN t ON c.department=t.department ORDER BY c.department, pct DESC;
```

### 11. Top 10% salaries globally.
```sql
WITH r AS (SELECT emp_id, salary, ROW_NUMBER() OVER (ORDER BY salary DESC) AS rn, COUNT(*) OVER () AS n FROM employees)
SELECT emp_id, salary FROM r WHERE rn <= CEIL(0.10*n) ORDER BY salary DESC;
```

### 12. Bottom 10% salaries globally.
```sql
WITH r AS (SELECT emp_id, salary, ROW_NUMBER() OVER (ORDER BY salary ASC) AS rn, COUNT(*) OVER () AS n FROM employees)
SELECT emp_id, salary FROM r WHERE rn <= CEIL(0.10*n) ORDER BY salary ASC;
```

### 13. Top degree by avg salary (global).
```sql
WITH a AS (SELECT degree, AVG(salary) AS a FROM employees GROUP BY degree)
SELECT degree, ROUND(a) AS avg_sal FROM a ORDER BY a DESC LIMIT 1;
```

### 14. Most common degree within each country.
```sql
WITH x AS (SELECT country, degree, COUNT(*) AS n FROM employees GROUP BY country, degree), r AS (SELECT *, ROW_NUMBER() OVER (PARTITION BY country ORDER BY n DESC, degree ASC) AS rn FROM x)
SELECT country, degree, n FROM r WHERE rn=1 ORDER BY country;
```

### 15. Most common department within each country.
```sql
WITH x AS (SELECT country, department, COUNT(*) AS n FROM employees GROUP BY country, department), r AS (SELECT *, ROW_NUMBER() OVER (PARTITION BY country ORDER BY n DESC, department ASC) AS rn FROM x)
SELECT country, department, n FROM r WHERE rn=1 ORDER BY country;
```

### 16. Oldest employee per department.
```sql
WITH r AS (SELECT emp_id, first_name, department, age, ROW_NUMBER() OVER (PARTITION BY department ORDER BY age DESC) AS rn FROM employees)
SELECT * FROM r WHERE rn=1;
```

### 17. Youngest employee per department.
```sql
WITH r AS (SELECT emp_id, first_name, department, age, ROW_NUMBER() OVER (PARTITION BY department ORDER BY age ASC) AS rn FROM employees)
SELECT * FROM r WHERE rn=1;
```

### 18. Most recent hire per department.
```sql
WITH r AS (SELECT emp_id, first_name, department, hire_date, ROW_NUMBER() OVER (PARTITION BY department ORDER BY hire_date DESC) AS rn FROM employees)
SELECT * FROM r WHERE rn=1;
```

### 19. Department salary variance (pop).
```sql
SELECT department, ROUND(VAR_POP(salary),2) AS var_pop FROM employees GROUP BY department ORDER BY var_pop DESC;
```

### 20. Country salary stddev (pop).
```sql
SELECT country, ROUND(STDDEV_POP(salary),2) AS sd_pop FROM employees GROUP BY country ORDER BY sd_pop DESC;
```

### 21. Departments with > 30% >120k salaries.
```sql
WITH x AS (SELECT department, SUM(CASE WHEN salary>120000 THEN 1 ELSE 0 END) AS hi, COUNT(*) AS n FROM employees GROUP BY department)
SELECT department, ROUND(hi*100.0/n,2) AS pct_hi FROM x WHERE hi*100.0/n > 30;
```

### 22. Most frequent last_name per department.
```sql
WITH x AS (SELECT department, last_name, COUNT(*) AS n FROM employees GROUP BY department, last_name), r AS (SELECT *, ROW_NUMBER() OVER (PARTITION BY department ORDER BY n DESC, last_name ASC) AS rn FROM x)
SELECT department, last_name, n FROM r WHERE rn=1;
```

### 23. Salary above both country & dept averages.
```sql
WITH ca AS (SELECT country, AVG(salary) AS a FROM employees GROUP BY country), da AS (SELECT department, AVG(salary) AS a FROM employees GROUP BY department)
SELECT e.emp_id, e.first_name, e.country, e.department, e.salary FROM employees e JOIN ca ON e.country=ca.country JOIN da ON e.department=da.department WHERE e.salary > ca.a AND e.salary > da.a ORDER BY e.salary DESC;
```

### 24. For each degree, % in Engineering.
```sql
WITH g AS (SELECT degree, SUM(CASE WHEN department='Engineering' THEN 1 ELSE 0 END) AS eng, COUNT(*) AS n FROM employees GROUP BY degree)
SELECT degree, ROUND(eng*100.0/n,2) AS pct_eng FROM g ORDER BY pct_eng DESC;
```

### 25. For each country, top 2 departments by avg salary.
```sql
WITH a AS (SELECT country, department, AVG(salary) AS a FROM employees GROUP BY country, department), r AS (SELECT *, ROW_NUMBER() OVER (PARTITION BY country ORDER BY a DESC) AS rn FROM a)
SELECT country, department, ROUND(a) AS avg_sal FROM r WHERE rn<=2 ORDER BY country, avg_sal DESC;
```

### 26. Coefficient of variation per department.
```sql
SELECT department, ROUND(STDDEV_POP(salary)/NULLIF(AVG(salary),0),3) AS cv FROM employees GROUP BY department ORDER BY cv DESC;
```

### 27. Salary z-score within department.
```sql
WITH a AS (SELECT department, AVG(salary) AS a, STDDEV_POP(salary) AS s FROM employees GROUP BY department)
SELECT e.emp_id, e.department, ROUND((e.salary - a.a)/NULLIF(a.s,0),2) AS z FROM employees e JOIN a ON e.department=a.department ORDER BY z DESC LIMIT 20;
```

