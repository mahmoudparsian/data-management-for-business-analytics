# Lab-2 – Basic to Intermediate (30 queries)

> Table: `employees(emp_id, first_name, last_name, age, degree, gender, country, department, hire_date, salary)`

### 1. Count employees per country.
```sql
SELECT country, COUNT(*) AS cnt FROM employees GROUP BY country ORDER BY cnt DESC;
```

### 2. Count employees per department.
```sql
SELECT department, COUNT(*) AS cnt FROM employees GROUP BY department ORDER BY cnt DESC;
```

### 3. Average salary overall.
```sql
SELECT AVG(salary) AS avg_salary FROM employees;
```

### 4. Average salary per department.
```sql
SELECT department, ROUND(AVG(salary)) AS avg_salary FROM employees GROUP BY department ORDER BY avg_salary DESC;
```

### 5. Average salary per country.
```sql
SELECT country, ROUND(AVG(salary)) AS avg_salary FROM employees GROUP BY country ORDER BY avg_salary DESC;
```

### 6. Min/max salary per degree.
```sql
SELECT degree, MIN(salary) AS min_sal, MAX(salary) AS max_sal FROM employees GROUP BY degree;
```

### 7. Employees per degree.
```sql
SELECT degree, COUNT(*) AS cnt FROM employees GROUP BY degree ORDER BY cnt DESC;
```

### 8. Employees hired each year.
```sql
SELECT YEAR(hire_date) AS yr, COUNT(*) AS cnt FROM employees GROUP BY YEAR(hire_date) ORDER BY yr;
```

### 9. Average age per department.
```sql
SELECT department, ROUND(AVG(age)) AS avg_age FROM employees GROUP BY department ORDER BY avg_age;
```

### 10. Employees with salary above department average.
```sql
SELECT e.* FROM employees e JOIN (SELECT department, AVG(salary) AS avg_sal FROM employees GROUP BY department) d ON e.department=d.department WHERE e.salary > d.avg_sal;
```

### 11. Employees with salary below country average.
```sql
SELECT e.emp_id, e.first_name, e.salary, e.country FROM employees e JOIN (SELECT country, AVG(salary) AS avg_sal FROM employees GROUP BY country) c ON e.country=c.country WHERE e.salary < c.avg_sal;
```

### 12. Departments having more than 30 employees.
```sql
SELECT department, COUNT(*) AS cnt FROM employees GROUP BY department HAVING COUNT(*)>30;
```

### 13. Countries with avg salary >= 100k.
```sql
SELECT country, ROUND(AVG(salary)) AS avg_sal FROM employees GROUP BY country HAVING AVG(salary) >= 100000;
```

### 14. Degrees with fewer than 20 employees.
```sql
SELECT degree, COUNT(*) AS cnt FROM employees GROUP BY degree HAVING COUNT(*) < 20;
```

### 15. Top 10 highest paid employees.
```sql
SELECT emp_id, first_name, last_name, salary FROM employees ORDER BY salary DESC LIMIT 10;
```

### 16. Bottom 10 salaries.
```sql
SELECT emp_id, first_name, last_name, salary FROM employees ORDER BY salary ASC LIMIT 10;
```

### 17. Median-ish (approx) placeholder.
```sql
SELECT 'See Lab 5 for window-based percentile' AS note;
```

### 18. Salary buckets (every 20k).
```sql
SELECT CONCAT(FLOOR(salary/20000)*20000,'-',FLOOR(salary/20000)*20000+19999) AS bucket, COUNT(*) AS cnt FROM employees GROUP BY bucket ORDER BY FLOOR(salary/20000);
```

### 19. Age groups via CASE.
```sql
SELECT CASE WHEN age<30 THEN 'Under30' WHEN age<=50 THEN '30to50' ELSE 'Over50' END AS age_group, COUNT(*) AS cnt FROM employees GROUP BY age_group;
```

### 20. Department + country counts.
```sql
SELECT department, country, COUNT(*) AS cnt FROM employees GROUP BY department, country ORDER BY department, cnt DESC;
```

### 21. Distinct full names (sanity).
```sql
SELECT COUNT(DISTINCT CONCAT(first_name,' ',last_name)) FROM employees;
```

### 22. Top 5 countries by headcount.
```sql
SELECT country, COUNT(*) AS cnt FROM employees GROUP BY country ORDER BY cnt DESC LIMIT 5;
```

### 23. Top 5 departments by avg age.
```sql
SELECT department, ROUND(AVG(age)) AS avg_age FROM employees GROUP BY department ORDER BY avg_age DESC LIMIT 5;
```

### 24. Employees with degree IN (MS, MBA, PHD).
```sql
SELECT emp_id, first_name, degree FROM employees WHERE degree IN ('MS','MBA','PHD');
```

### 25. Employees NOT from (USA, CANADA).
```sql
SELECT emp_id, first_name, country FROM employees WHERE country NOT IN ('USA','CANADA') LIMIT 20;
```

### 26. Employees hired in Q1 of any year.
```sql
SELECT emp_id, first_name, hire_date FROM employees WHERE MONTH(hire_date) IN (1,2,3);
```

### 27. Count of employees hired per month (across all years).
```sql
SELECT MONTH(hire_date) AS m, COUNT(*) FROM employees GROUP BY MONTH(hire_date) ORDER BY m;
```

### 28. Top 10 youngest in Engineering.
```sql
SELECT emp_id, first_name, age FROM employees WHERE department='Engineering' ORDER BY age ASC LIMIT 10;
```

### 29. Top 10 oldest in HR.
```sql
SELECT emp_id, first_name, age FROM employees WHERE department='HR' ORDER BY age DESC LIMIT 10;
```

### 30. Check rows with odd characters in first_name.
```sql
SELECT emp_id, first_name FROM employees WHERE first_name REGEXP '[^A-Za-z]';
```

