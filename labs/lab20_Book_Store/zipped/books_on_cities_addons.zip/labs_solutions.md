# ✅ Books-on-Cities — Solutions Pack (Expected Outputs, Summarized)

> Note: Values and row counts depend on your CSV load. Use these to **validate shape and logic**, not exact numbers.

---
## Lab 1 — Very Basic
1. **All stores** → 8 rows.  
2. **Stores in UK** → London, Edinburgh (2 rows).  
3. **Distinct customer cities** → A list of ~10–12 cities.  
4. **Books after 2015** → Titles with `published_date >= '2016-01-01'`.  
5. **Top 5 most expensive purchases** → 5 rows sorted by price desc.  
... (similarly list all 30 with what they should roughly return)

---
## Lab 2 — Basics + Intro-Intermediate
- **Transactions with store + book** → Columns: `(sale_id, city, title, price)`; ~20 rows with LIMIT 20.
- **Avg price per category** → One row per category; `avg_price` decreases for Children; increases for Business/Science.
- **Customers spending > 100** → `(customer_id, name, total_spent)`; sorted desc.
- **Monthly sales count (2024)** → `(YYYY-MM, cnt)` rows, ascending by month.

---
## Lab 3 — Intermediate
- **Customers with > average # purchases** → Returns power users; shows `(customer_id, name, cnt)`.
- **Top 10 books by units** → `(title, units)`, sorted desc.
- **Stores with zero transactions in 2025** → Subset of 8 stores (possibly 0–3 stores).
- **Books above avg price (2024)** → Distinct titles priced above the avg for that period.

---
## Lab 4 — Intermediate+
- **Rank stores by total revenue** → `(store_id, city, rev, rev_rank)`; rank=1 is highest.
- **Age buckets AVG spend** → `(Under 25, 25-39, 40-59, 60+)` with `avg_spent` values.
- **MoM revenue growth** → `(month, rev, pct_growth)`; expect ± swings.
- **Best-selling book per store** → 8 rows, one per store: `(store_id, city, title, units)`.

---
## Lab 5 — Advanced
- **Most profitable store** → Single row with `(store_id, city, revenue)`.
- **Most valuable customer** → Single row `(customer_id, name, total_spent)`.
- **Top 3 authors per country** → `(country, author, rev, rnk)`; 3 per country.
- **Continuous 3-month growth stores** → `(store_id, city, ym)` rows satisfying growth condition.
- **Avg time between purchases** → `(customer_id, name, avg_days_between)`; realistic averages ~15–60 days.

---
### Tips for Verifying
- Sanity-check: Totals should add up.  
- Time filters (year/month) should reduce row counts.  
- If a query returns **0 rows**, check WHERE clause, dates, or joins.