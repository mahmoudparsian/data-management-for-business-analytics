# Lab 1 — Very Basic Queries

Schema (simplified):

```sql
stores(store_id, store_location, city, country)
customers(customer_id, name, email, gender, age, city, country)
books(book_id, ISBN, title, author, category, published_date)
transactions(sale_id, store_id, book_id, customer_id, purchase_date, price)
```

## Stores

**1. List all stores.**
```sql
SELECT * FROM stores;
```

**2. Show store_id and city for all stores.**
```sql
SELECT store_id, city FROM stores;
```

**3. Find stores in the UK.**
```sql
SELECT * FROM stores WHERE country='UK';
```

**4. List stores ordered by city A→Z.**
```sql
SELECT * FROM stores ORDER BY city ASC;
```

**5. Count stores per country.**
```sql
SELECT country, COUNT(*) FROM stores GROUP BY country;
```

**6. Find store(s) located in London.**
```sql
SELECT * FROM stores WHERE city='London';
```

## Customers

**7. List first 10 customers.**
```sql
SELECT * FROM customers LIMIT 10;
```

**8. Find customers older than 40.**
```sql
SELECT * FROM customers WHERE age > 40;
```

**9. Show distinct customer cities.**
```sql
SELECT DISTINCT city FROM customers;
```

**10. Customers in the same country as 'London' store (UK).**
```sql
SELECT * FROM customers WHERE country='UK';
```

**11. Customers with email ending in 'mail.com'.**
```sql
SELECT * FROM customers WHERE email LIKE '%@mail.com';
```

**12. Count customers by gender.**
```sql
SELECT gender, COUNT(*) FROM customers GROUP BY gender;
```

## Books

**13. List 10 books (title, author).**
```sql
SELECT title, author FROM books LIMIT 10;
```

**14. Find all books in 'Fiction' category.**
```sql
SELECT * FROM books WHERE category='Fiction';
```

**15. Books published after 2015.**
```sql
SELECT * FROM books WHERE published_date >= '2016-01-01';
```

**16. Show distinct categories.**
```sql
SELECT DISTINCT category FROM books;
```

**17. Count books per category.**
```sql
SELECT category, COUNT(*) FROM books GROUP BY category;
```

**18. Find books with 'City' in the title.**
```sql
SELECT * FROM books WHERE title LIKE '%City%';
```

## Transactions

**19. Show 10 sample transactions.**
```sql
SELECT * FROM transactions LIMIT 10;
```

**20. Find transactions above price 25.**
```sql
SELECT * FROM transactions WHERE price > 25;
```

**21. Transactions in 2024.**
```sql
SELECT * FROM transactions WHERE purchase_date BETWEEN '2024-01-01' AND '2024-12-31';
```

**22. Count transactions per store.**
```sql
SELECT store_id, COUNT(*) FROM transactions GROUP BY store_id;
```

**23. Average price of all transactions.**
```sql
SELECT AVG(price) FROM transactions;
```

**24. Top 5 most expensive purchases.**
```sql
SELECT * FROM transactions ORDER BY price DESC LIMIT 5;
```

## Extras

**25. Customers ordered by name.**
```sql
SELECT * FROM customers ORDER BY name;
```

**26. Latest 5 published books.**
```sql
SELECT * FROM books ORDER BY published_date DESC LIMIT 5;
```

**27. Cheapest 5 transactions.**
```sql
SELECT * FROM transactions ORDER BY price ASC LIMIT 5;
```

**28. Stores in USA or UK.**
```sql
SELECT * FROM stores WHERE country IN ('USA','UK');
```

**29. Customers aged between 25 and 35.**
```sql
SELECT * FROM customers WHERE age BETWEEN 25 AND 35;
```

**30. Books not in 'Children' category.**
```sql
SELECT * FROM books WHERE category <> 'Children';
```

