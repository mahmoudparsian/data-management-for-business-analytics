INSERT INTO stores (store_id, store_location, city, country) VALUES
(1, 'Downtown Bookstore', 'New York', 'USA'),
(2, 'City Center Books', 'San Francisco', 'USA'),
(3, 'Riverside Books & Café', 'Toronto', 'Canada'),
(4, 'Sunset Pages', 'London', 'UK'),
(5, 'Harbor Lights Books', 'Berlin', 'Germany'),
(6, 'Grand Bazaar Books', 'Paris', 'France'),
(7, 'Skyline Reads', 'Sydney', 'Australia'),
(8, 'Garden Lane Bookshop', 'Tokyo', 'Japan'),
(9, 'Aurora Books & Tea', 'Mexico City', 'Mexico');
