**Q1.** Find the most played song overall using a CTE.

**Q2.** Find the top 3 most played songs using RANK.

**Q3.** Find the most active user per country.

**Q4.** Find the least played song using CTE.

**Q5.** Find the average plays per user using CTE.

**Q6.** Find the top 2 artists by play count.

**Q7.** Find the most popular genre using CTE.

**Q8.** Find users who played more than average songs.

**Q9.** Find the user with maximum distinct songs played.

**Q10.** Find songs never played by any user.

**Q11.** Find devices ranked by number of plays.

**Q12.** Find users ranked by number of plays.

**Q13.** Find the most played artist per country.

**Q14.** Find the most played genre in 2020.

**Q15.** Find users who played songs on more than one device.

**Q16.** Find the top 2 most played songs per genre.

**Q17.** Find the most played song per quarter.

**Q18.** Find users ranked by plays within their country.

**Q19.** Find artists ranked by average song duration.

**Q20.** Find songs longer than the average duration using CTE.