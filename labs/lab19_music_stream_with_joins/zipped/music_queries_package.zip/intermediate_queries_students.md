**Q1.** Find the number of users in each country.

**Q2.** Find the number of songs per genre.

**Q3.** Count the number of free and premium users.

**Q4.** Find the average duration of songs per genre.

**Q5.** Find the longest song per artist.

**Q6.** Count how many plays each user has.

**Q7.** Find the total plays of each song.

**Q8.** Find the number of plays per device.

**Q9.** Find the number of songs played per day.

**Q10.** Find the number of songs played per month in 2020.

**Q11.** Find all users and the number of distinct songs they have played.

**Q12.** Find the most played song in 2020.

**Q13.** Find total plays per country.

**Q14.** Find average song duration by artist.

**Q15.** Find songs played by user 'alex'.

**Q16.** Find how many distinct users played each genre.

**Q17.** Find the top 5 most played songs.

**Q18.** Find the number of plays in each quarter.

**Q19.** Find all users who never played any song.

**Q20.** Find the number of plays for Beatles songs.