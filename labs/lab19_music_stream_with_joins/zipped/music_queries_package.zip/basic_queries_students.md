**Q1.** List all users from USA.

**Q2.** Show all songs by Taylor Swift.

**Q3.** Find the names and emails of all free plan users.

**Q4.** Show all premium plan users from Spain.

**Q5.** Display all songs in the rock genre.

**Q6.** Find all users who have null subscription plan.

**Q7.** List all songs longer than 250 seconds.

**Q8.** Find all users whose name is 'ted'.

**Q9.** Show all distinct countries of users.

**Q10.** Display all songs by Beatles ordered by duration.

**Q11.** List all devices available in the system.

**Q12.** Find all users from Brazil.

**Q13.** Show songs with duration less than 200 seconds.

**Q14.** Find all users on premium plan in France.

**Q15.** List all pop songs by Ed Sheeran.

**Q16.** Show all classical songs by Mozart.

**Q17.** Find all unique subscription plans.

**Q18.** List all users whose email ends with 'tennis.com'.

**Q19.** Show all songs titled 'The 1'.

**Q20.** Display all songs not in the 'pop' genre.