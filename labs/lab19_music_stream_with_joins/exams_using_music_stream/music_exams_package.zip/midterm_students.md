**Q1.** List all premium users from France.

**Q2.** Find all songs longer than 250 seconds.

**Q3.** Count the number of users per country.

**Q4.** Find the average duration of songs in each genre.

**Q5.** Show the longest song by each artist.

**Q6.** List all plays along with user name and song title.

**Q7.** Find the number of plays per device.

**Q8.** Show all users who never played any song.

**Q9.** Find the most played song overall.

**Q10.** Find the number of distinct users who played each genre.

**Q11.** Show the most popular artist (by play count).

**Q12.** Find the number of plays per quarter in 2020.

**Q13.** Find all songs played by user 'alex'.

**Q14.** Count free vs premium users.

**Q15.** Show the top 5 most played songs.

