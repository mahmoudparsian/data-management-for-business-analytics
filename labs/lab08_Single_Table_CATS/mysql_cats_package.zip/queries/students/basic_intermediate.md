1. Count cats per country.

2. Count cats per breed.

3. Count cats by gender.

4. Average tricks by breed.

5. Average age by country.

6. Max and min age by breed.

7. Top 3 breeds by number of cats.

8. Breeds with at least 8 average tricks.

9. Countries with fewer than 10 cats.

10. Total cats and total tricks overall.

11. Share of each gender overall.

12. Count of cats per (country, gender).

13. Breeds seen in more than 3 countries.

14. Average age per birth year.

15. Cats per age, descending count.

16. Average tricks by gender in USA.

17. Countries where avg age > 6.

18. Top 5 countries by avg tricks.

19. Join: show breed descriptions for 10 cats.

20. Name frequency table (top 10).

