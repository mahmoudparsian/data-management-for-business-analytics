1. Cats with zero tricks (CTE).

2. Breeds never seen in GERMANY (CTE + anti-join).

3. Top breed per country by count (CTE + rank).

4. Countries where avg tricks exceeds global avg.

5. For each breed, top 2 cats by tricks.

6. Most common breed per gender.

7. Breeds with avg age above overall avg.

8. Per breed, month with most births.

9. Countries with at least 60% females.

10. Top 5 most frequent names (CTE).

11. Breeds present in at least 4 countries.

12. Country with highest average age (CTE + rank).

13. USA: top 3 breeds by avg tricks.

14. Cats whose age > breed's avg age.

15. Countries with youngest average age (rank=1).

16. Per breed, USA ratio.

17. Countries where most common breed is 'Persian'.

18. Within each country, dense rank breeds by count.

19. Top 5 (country, breed) by avg age.

20. Outliers: tricks >= 2 stddev above mean.

