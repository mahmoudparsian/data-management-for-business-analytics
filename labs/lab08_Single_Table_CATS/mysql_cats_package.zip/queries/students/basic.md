1. List all cats.

2. Show cat names and breeds.

3. Find cats from USA.

4. Find female cats.

5. Cats older than 5.

6. Cats with at least 5 tricks.

7. Cats born in 2020.

8. List distinct countries represented.

9. Find cats named 'Luna'.

10. Top 10 youngest by age (ascending age, then id).

11. Cats not from GERMANY.

12. Find all male Bengals.

13. Breeds in the dataset.

14. Find cats whose name starts with 'M'.

15. Find cats born after 2022-01-01.

16. Cats with 0 tricks.

17. Count how many cats are named 'Leo'.

18. Show the 5 most recent DOBs.

19. List cats with age between 3 and 7 inclusive.

20. Find cats from CANADA or FRANCE.

