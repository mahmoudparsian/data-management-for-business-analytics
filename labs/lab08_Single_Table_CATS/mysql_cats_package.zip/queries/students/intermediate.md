1. Rank breeds by total cats.

2. Top 3 breeds within each country by count.

3. Rank countries by average tricks.

4. Row number of each cat within its breed by DOB desc.

5. Top/Bottom by DOB per breed (rn=1 oldest vs youngest).

6. Rank genders by avg tricks within each country.

7. Top 10 cats by tricks (wrap rank).

8. Cumulative count of cats by ascending id.

9. Rank ages by popularity.

10. Within each breed, rank countries by average age.

11. Rank countries by proportion of females.

12. Per country, top breed by avg tricks.

13. Rank breeds by avg age (descending).

14. Top 5 names by frequency.

15. Within each breed, dense rank by tricks.

16. Rank countries by number of breeds present.

17. Top 3 youngest cats per country.

18. Rank breeds by average birth year.

19. Within each country, rank genders by count.

20. Rank breeds by USA share (CTE).

